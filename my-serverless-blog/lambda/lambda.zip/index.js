exports.handler = async (event) => {
    const name = event.queryStringParameters && event.queryStringParameters.name 
                 ? event.queryStringParameters.name 
                 : "Gezgin";

    // Örnek parametre ile işlem: sayının karesi
    const number = event.queryStringParameters && event.queryStringParameters.number 
                   ? parseFloat(event.queryStringParameters.number) 
                   : null;

    let resultMessage;
    if (number !== null && !isNaN(number)) {
        resultMessage = `${number} sayısının karesi ${number * number}`;
    }

    const response = {
        statusCode: 200,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            message: `Merhaba ${name}, bu fonksiyon AWS Lambda üzerinde çalışıyor! 🐧🌌`,
            squareResult: resultMessage,
            theme: "Star Wars + Linux + Çizgi Roman"
        }),
    };

    console.log("Lambda log:", response.body);
    return response;
};
